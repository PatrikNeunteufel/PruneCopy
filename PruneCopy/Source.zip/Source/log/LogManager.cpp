/*****************************************************************//**
 * @file   LogManager.cpp
 * @brief  Implements logging functionality for PruneCopy
 *         with optional colored output on supported terminals
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#include "log/LogManager.hpp"
#include "core/PruneOptions.hpp"

#include <iostream>
#include <iomanip>
#include <sstream>
#include <algorithm>
#include <stdexcept>

#ifdef _WIN32
#include <windows.h>
#endif

namespace LogManager {

    static LogLevel currentConsoleLevel = LogLevel::Info;
    static bool ansiColorEnabled = false;

    // ANSI escape codes
    const char* ANSI_RESET = "\033[0m";
    const char* ANSI_BLUE = "\033[34m";
    const char* ANSI_YELLOW = "\033[33m";
    const char* ANSI_RED = "\033[31m";

    void setConsoleLogLevel(LogLevel level) {
        currentConsoleLevel = level;
    }

    std::string formatTag(const std::string& label) {
        std::ostringstream oss;
        oss << "[" << std::left << std::setw(10) << label << "] ";
        return oss.str();
    }

    std::string levelToString(LogLevel level) {
        switch (level) {
        case LogLevel::Info:    return "Info";
        case LogLevel::Warning: return "Warning";
        case LogLevel::Error:   return "Error";
        default:                return "Log";
        }
    }

    LogLevel parseLogLevel(const std::string& str) {
        std::string s = str;
        std::transform(s.begin(), s.end(), s.begin(), ::tolower);
        if (s == "info")    return LogLevel::Info;
        if (s == "warning") return LogLevel::Warning;
        if (s == "error")   return LogLevel::Error;
        throw std::invalid_argument("Invalid log level: " + str);
    }

    void enableAnsiColorsIfSupported(ColorMode mode) {
        if (mode == ColorMode::Never) {
            ansiColorEnabled = false;
            return;
        }

#ifdef _WIN32
        HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
        if (hOut == INVALID_HANDLE_VALUE) return;

        DWORD dwMode = 0;
        if (!GetConsoleMode(hOut, &dwMode)) return;

        dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
        if (SetConsoleMode(hOut, dwMode)) {
            ansiColorEnabled = true;
        }
#else
        ansiColorEnabled = true;
#endif

        if (mode == ColorMode::Always) {
            ansiColorEnabled = true; // forced on regardless of detection
        }
    }


    void log(LogLevel level, const std::string& message, std::ostream* stream) {
        if (!stream) return;
        if (stream == &std::cout && level < currentConsoleLevel) return;

        std::string colorPrefix;
        switch (level) {
        case LogLevel::Info:    colorPrefix = ANSI_BLUE; break;
        case LogLevel::Warning: colorPrefix = ANSI_YELLOW; break;
        case LogLevel::Error:   colorPrefix = ANSI_RED; break;
        }

        if (stream == &std::cout && ansiColorEnabled)
            *stream << colorPrefix;

        *stream << formatTag(levelToString(level)) << ANSI_RESET << message;

        if (stream == &std::cout && ansiColorEnabled)
            *stream << ANSI_RESET;

        *stream << std::endl;
    }

    void logRaw(const std::string& tag, const std::string& message, std::ostream* stream) {
        if (!stream) return;
        *stream << formatTag(tag) << message << std::endl;
    }

}

