﻿/*****************************************************************//**
 * @file   LogManager.hpp
 * @brief  Provides logging utilities for console and file output
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#pragma once
#include <string>
#include <iostream> // ← damit std::ostream & std::cout bekannt sind

#include "cli/ArgumentParser.hpp"
#include "core/PruneOptions.hpp"

namespace LogManager {

    /**
     * @brief Sets the minimum log level for console output.
     * Messages below this level will be suppressed.
     */
    void setConsoleLogLevel(LogLevel level);

    /**
     * @brief Converts LogLevel to readable string.
     */
    std::string levelToString(LogLevel level);

    /**
     * @brief Parses a string like "info", "warning", "error" into a LogLevel enum.
     *        Throws if invalid.
     */
    LogLevel parseLogLevel(const std::string& str);

    /**
     * @brief Formats a tag with padding (e.g., [Info      ]).
     */
    std::string formatTag(const std::string& label);

    /**
     * @brief Logs a message with given level to the provided stream.
     * Respects the configured console log level.
     */
    void log(LogLevel level, const std::string& message, std::ostream* stream = &std::cout);

    /**
     * @brief Logs a raw message with a custom tag (no level filtering).
     */
    void logRaw(const std::string& tag, const std::string& message, std::ostream* stream = &std::cout);


    /**
    * @brief Initializes console color support depending on platform and color mode.
    */
    void enableAnsiColorsIfSupported(ColorMode mode = ColorMode::Auto);

}

