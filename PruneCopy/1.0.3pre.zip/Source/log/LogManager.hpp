﻿/*****************************************************************//**
 * @file   LogManager.hpp
 * @brief  Provides logging utilities for console and file output
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#pragma once

#include <string>
#include <fstream>
#include <iostream>

#include "core/PruneOptions.hpp"


enum class LogType {
    Info,
    Success,
    Copied,
    Overwritten,
    Skipped,
    Deleted,
    Conflict,
    Aborted,
    Error,
	UserInput,
    Custom
};



class LogManager {
public:
    static void setConsoleLogLevel(LogLevel level);
    static void setLogFile(std::ofstream* file);
    static void enableAnsiColorsIfSupported(ColorMode mode);

    static void log(LogType type, const std::string& message, std::ostream* stream = &std::cout);
    static void log(LogLevel level, const std::string& message, std::ostream* stream = &std::cout);
    static void logToAll(LogType type, const std::string& msg, std::ostream* logFile);
    static void logToAll(LogLevel level, const std::string& msg, std::ostream* logFile);
    static void logAlwaysToConsole(LogType type, const std::string& message);
    static void logAlwaysToConsole(LogLevel level, const std::string& message);
private:
    static LogLevel logLevelFromType(LogType type);
    static std::string tagFromType(LogType type);
    static std::string applyColor(LogLevel level, const std::string& tag);
    static bool shouldLog(LogLevel level);

    static inline LogLevel s_consoleLogLevel = LogLevel::Info;
    static inline std::ofstream* s_logFile = nullptr;
    static inline bool s_ansiColorEnabled = false;
};
