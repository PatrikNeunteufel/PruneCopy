/*****************************************************************//**
 * @file   LogManager.cpp
 * @brief  Implements logging functionality for PruneCopy
 *         with optional colored output on supported terminals
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/


#include "log/LogManager.hpp"

#include <map>
#include <unordered_map>
#include <sstream>
#include <iomanip>
#include <algorithm>


#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#endif

void LogManager::setConsoleLogLevel(LogLevel level) {
    s_consoleLogLevel = level;
}

void LogManager::setLogFile(std::ofstream* file) {
    s_logFile = file;
}

void LogManager::enableAnsiColorsIfSupported(ColorMode mode) {
    if (mode == ColorMode::Never) {
        s_ansiColorEnabled = false;
        return;
    }

#ifdef _WIN32
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut == INVALID_HANDLE_VALUE) return;

    DWORD dwMode = 0;
    if (!GetConsoleMode(hOut, &dwMode)) return;

    dwMode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    if (SetConsoleMode(hOut, dwMode)) {
        s_ansiColorEnabled = true;
    }
#else
    s_ansiColorEnabled = true;
#endif

    if (mode == ColorMode::Always) {
        s_ansiColorEnabled = true;
    }
}

static const std::unordered_map<LogType, std::string>& getLogLabelMap() {
    static const std::unordered_map<LogType, std::string> labelMap = {
        { LogType::Info,        "Info" },
        { LogType::Success,     "Success" },
        { LogType::Copied,      "Copied" },
        { LogType::Overwritten, "Overwritten" },
        { LogType::Skipped,     "Skipped" },
        { LogType::Deleted,     "Deleted" },
        { LogType::Conflict,    "Conflict" },
        { LogType::Aborted,     "Aborted" },
		{ LogType::Error,       "Error" },
		{ LogType::UserInput,   "UserInput" },
        { LogType::Custom,      "Log" }
    };
    return labelMap;
}

static size_t getMaxLogLabelLength() {
    const auto& labels = getLogLabelMap();
    size_t maxLen = 0;
    for (const auto& [key, label] : labels) {
        maxLen = std::max(maxLen, label.size());
    }
    return maxLen;
}

LogLevel LogManager::logLevelFromType(LogType type) {
    static const std::unordered_map<LogType, LogLevel> typeToLevel = {
        { LogType::Info,        LogLevel::Info },
        { LogType::Success,     LogLevel::Standard },
        { LogType::Copied,      LogLevel::Standard },
        { LogType::Overwritten, LogLevel::Standard },
        { LogType::Skipped,     LogLevel::Standard },
        { LogType::Deleted,     LogLevel::Standard },
        { LogType::Conflict,    LogLevel::Warning },
        { LogType::Aborted,     LogLevel::Standard },
		{ LogType::Error,       LogLevel::Error },
		{ LogType::UserInput,   LogLevel::Info },
        { LogType::Custom,      LogLevel::Info }
    };
    auto it = typeToLevel.find(type);
    return it != typeToLevel.end() ? it->second : LogLevel::Info;
}

std::string LogManager::tagFromType(LogType type) {
    const auto& map = getLogLabelMap();
    std::string label = map.contains(type) ? map.at(type) : "Info";

    std::ostringstream oss;
    oss << "[" << std::left << std::setw(getMaxLogLabelLength()) << label << "]";
    return oss.str();
}

std::string LogManager::applyColor(LogLevel level, const std::string& tag) {
    if (!s_ansiColorEnabled) return tag;

    switch (level) {
    case LogLevel::Error:    return "\033[1;31m" + tag + "\033[0m"; // rot
    case LogLevel::Warning:  return "\033[1;33m" + tag + "\033[0m"; // gelb
    case LogLevel::Standard: return "\033[1;34m" + tag + "\033[0m"; // blau
    case LogLevel::Info:     return "\033[1;36m" + tag + "\033[0m"; // cyan
    default:                 return tag;
    }
}

bool LogManager::shouldLog(LogLevel level) {
    return level >= s_consoleLogLevel;
}

void LogManager::log(LogType type, const std::string& message, std::ostream* stream) {
    LogLevel level = logLevelFromType(type);
    //std::cout << "type: " << static_cast<int>(type)
    //    << ", level: " << static_cast<int>(level)
    //    << ", shouldLog: " << shouldLog(level)
    //    << ", stream == cout: " << (stream == &std::cout)
    //    << std::endl;
    if (!shouldLog(level)) return;

    std::string rawTag = tagFromType(type);
    std::string coloredTag = applyColor(level, rawTag);


    // nur farbig, wenn explizit auf Konsole
    if (stream && stream == &std::cout && shouldLog(level)) {
        *stream << coloredTag << " " << message << std::endl;
    }

    if (s_logFile && s_logFile->is_open()) {
        *s_logFile << rawTag << " " << message << std::endl;
    }
}

void LogManager::log(LogLevel level, const std::string& message, std::ostream* stream) {
    if (!shouldLog(level)) return;

    std::string label;
    switch (level) {
    case LogLevel::Info:     label = "Info"; break;
    case LogLevel::Warning:  label = "Warning"; break;
    case LogLevel::Error:    label = "Error"; break;
    case LogLevel::Standard: label = "Standard"; break;
    default:                 label = "Log"; break;
    }

    std::ostringstream oss;
    oss << "[" << std::left << std::setw(getMaxLogLabelLength()) << label << "]";
    std::string rawTag = oss.str();
    std::string coloredTag = applyColor(level, rawTag);


    // nur farbig, wenn explizit auf Konsole
    if (stream && stream == &std::cout && shouldLog(level)) {
        *stream << coloredTag << " " << message << std::endl;
    }

    if (s_logFile && s_logFile->is_open()) {
        *s_logFile << rawTag << " " << message << std::endl;
    }
}
void LogManager::logToAll(LogType type, const std::string& msg, std::ostream* logFile) {
    LogManager::log(type, msg, &std::cout);
    LogManager::log(type, msg, logFile);
}
void LogManager::logToAll(LogLevel level, const std::string& msg, std::ostream* logFile)
{
	LogManager::log(level, msg, &std::cout);
	LogManager::log(level, msg, logFile);
}
void LogManager::logAlwaysToConsole(LogType type, const std::string& message) {
    LogLevel level = logLevelFromType(type);
    std::string tag = tagFromType(type);
    std::string colored = applyColor(level, tag);
    std::cout << colored << " " << message << std::endl;
}

void LogManager::logAlwaysToConsole(LogLevel level, const std::string& message)
{
	std::string tag = tagFromType(LogType::Info);
	std::string colored = applyColor(level, tag);
	std::cout << colored << " " << message << std::endl;
}
