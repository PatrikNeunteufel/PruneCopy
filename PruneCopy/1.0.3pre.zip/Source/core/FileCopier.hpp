/*****************************************************************//**
 * @file   FileCopier.hpp
 * @brief  Provides file filtering and copying logic for PruneCopy
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#pragma once
#include <string>
#include <vector>
#include <filesystem>
#include <fstream>

#include "core/PruneOptions.hpp"

class FileCopier {
public:
    explicit FileCopier(const PruneOptions& options, std::ofstream* logFile = nullptr);

    void execute();

    // Legacy compatibility (for current testing and CLI integration)
    static void copyFiltered(const PruneOptions& options, std::ofstream* logFile = nullptr);
    static bool isExcludedDir(const std::filesystem::path& dir, const std::vector<std::string>& excludeDirs);

protected:
    std::filesystem::path resolveTargetPath(const std::filesystem::path& srcRoot,
        const std::filesystem::path& currentFile,
        const std::filesystem::path& destRoot) const;

    bool handleOverwritePrompt(const std::filesystem::path& targetFile);
    void logCopy(const std::filesystem::path& path);

protected:
    const PruneOptions& m_options;
    std::ofstream* m_logFile;
};
