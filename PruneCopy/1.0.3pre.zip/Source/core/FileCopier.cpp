﻿/*****************************************************************//**
 * @file   FileCopier.cpp
 * @brief  Implements file filtering and copying logic for PruneCopy
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#include "core/FileCopier.hpp"

#include <iostream>
#include <fstream>
#include <filesystem>
#include <string>
#include <algorithm>

#include "util/PatternUtils.hpp"
#include "log/LogManager.hpp"

namespace fs = std::filesystem;

FileCopier::FileCopier(const PruneOptions& options, std::ofstream* logFile)
    : m_options(options), m_logFile(logFile) {
}

void FileCopier::execute() {
    for (const auto& src : m_options.sources) {
        for (auto it = fs::recursive_directory_iterator(src); it != fs::recursive_directory_iterator(); ++it) {
            const auto& entry = *it;

            if (entry.is_directory() && PatternUtils::isExcludedDir(entry.path(), m_options.excludeDirs)) {
                LogManager::logToAll(LogType::Skipped, entry.path().string(), m_logFile);
                it.disable_recursion_pending();
                continue;
            }

            if (!entry.is_regular_file()) continue;
            const std::string filename = entry.path().filename().string();

            if (!m_options.typePatterns.empty() &&
                !PatternUtils::matchesPattern(filename, m_options.typePatterns)) continue;

            if (!m_options.excludeFilePatterns.empty() &&
                PatternUtils::matchesPattern(filename, m_options.excludeFilePatterns)) continue;

            for (const auto& dst : m_options.destinations) {
                fs::path targetFile = resolveTargetPath(src, entry.path(), dst);

                if (fs::exists(targetFile)) {
                    if (m_options.noOverwrite) continue;
                    if (!m_options.forceOverwrite && !handleOverwritePrompt(targetFile)) continue;
                }

                if (!m_options.dryRun) {
                    fs::create_directories(targetFile.parent_path());
                    fs::copy_file(entry.path(), targetFile, fs::copy_options::overwrite_existing);
                }

                LogManager::logToAll(LogType::Copied, targetFile.string(), m_logFile);
            }
        }
    }
}

fs::path FileCopier::resolveTargetPath(const fs::path& srcRoot, const fs::path& currentFile, const fs::path& destRoot) const {
    fs::path relPath = fs::relative(currentFile, srcRoot);

    if (m_options.flatten) {
        std::string filename = currentFile.filename().string();

        if (m_options.flattenWithSuffix) {
            std::string prefix = relPath.parent_path().string();
            std::replace(prefix.begin(), prefix.end(), '\\', '_');
            std::replace(prefix.begin(), prefix.end(), '/', '_');
            filename = prefix + "_" + filename;
        }

        return destRoot / filename;
    }

    return destRoot / relPath;
}

bool FileCopier::handleOverwritePrompt(const fs::path& targetFile) {
    while (true) {
        LogManager::logAlwaysToConsole(LogType::Conflict, targetFile.string() + " - overwrite? [y]es / [n]o / [a]ll / [s]kip all / [c]ancel:");
        std::string input;
        std::getline(std::cin, input);
        LogManager::logToAll(LogType::UserInput, "User entered: " + input, m_logFile);
        if (input.empty()) continue;

        char answer = std::tolower(input[0]);
        switch (answer) {
        case 'y': return true;
        case 'n': return false;
        case 'a':
            const_cast<PruneOptions&>(m_options).forceOverwrite = true;
            return true;
        case 's':
            const_cast<PruneOptions&>(m_options).noOverwrite = true;
            return false;
        case 'c':
            //LogManager::log(LogType::Aborted, "Operation cancelled by user.", m_logFile);
            LogManager::logToAll(LogType::Aborted, "Operation cancelled by user.", m_logFile);
            exit(0);
        default:
            continue;
        }
    }
}

void FileCopier::logCopy(const fs::path& path) {
    //LogManager::log(LogType::Copied, path.string(), m_logFile);
	LogManager::logToAll(LogType::Copied, path.string(), m_logFile);
}

// Hybrid-Kompatibilität

bool FileCopier::isExcludedDir(const fs::path& dir, const std::vector<std::string>& excludeDirs) {
    return PatternUtils::isExcludedDir(dir, excludeDirs);
}

void FileCopier::copyFiltered(const PruneOptions& options, std::ofstream* logFile) {
    FileCopier copier(options, logFile);
    copier.execute();
}
