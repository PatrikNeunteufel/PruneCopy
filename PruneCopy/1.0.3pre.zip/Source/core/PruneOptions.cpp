/*****************************************************************//**
 * @file   PruneOptions.cpp
 * @brief  
 * 
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#include "core/PruneOptions.hpp"