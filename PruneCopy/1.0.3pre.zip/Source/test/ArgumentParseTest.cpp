/*****************************************************************//**
 * @file   ArgumentParseTest.cpp
 * @brief  Tests ArgumentParser behavior with simulated CLI input
 *
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#include "ArgumentParseTest.hpp"
#include "test/TestUtils.hpp"

#include "cli/ArgumentParser.hpp"
#include "core/PruneOptions.hpp"

#include <iostream>
#include <sstream>

bool ArgumentParseTest::run() {
    std::cout << "[ArgumentParseTest] Running tests..." << std::endl;
    bool success = true;

    success &= testLegacyMode();
    success &= testFullCLIMode();
    success &= testColorMode();
    success &= testDeprecatedDetection();
    success &= testDeprecatedClear();

    if (success)
        std::cout << "[ArgumentParseTest] All tests passed!" << std::endl;
    else
        std::cout << "[ArgumentParseTest] Some tests FAILED!" << std::endl;

    return success;
}

bool ArgumentParseTest::testLegacyMode() {
    const char* argv[] = { "prunecopy", "source", "target" };
    int argc = sizeof(argv) / sizeof(argv[0]);
    PruneOptions opts;

    ArgumentParser::parse(argc, const_cast<char**>(argv), opts);

    bool success = true;
    success &= TestUtils::assertEqual(1u, opts.sources.size(), "LegacyMode: 1 source");
    success &= TestUtils::assertEqual(1u, opts.destinations.size(), "LegacyMode: 1 destination");
    return success;
}

bool ArgumentParseTest::testFullCLIMode() {
    const char* argv[] = {
        "prunecopy",
        "--source", "src1",
        "--destination", "dst1",
        "--dry-run",
        "--force-overwrite",
        "--log-dir", "logs",
        "--log-level", "error"
    };
    int argc = sizeof(argv) / sizeof(argv[0]);
    PruneOptions opts;

    ArgumentParser::parse(argc, const_cast<char**>(argv), opts);

    bool success = true;
    success &= TestUtils::assertEqual(1u, opts.sources.size(), "CLI: 1 source");
    success &= TestUtils::assertEqual(1u, opts.destinations.size(), "CLI: 1 destination");
    success &= TestUtils::assertTrue(opts.dryRun, "CLI: dry-run");
    success &= TestUtils::assertTrue(opts.forceOverwrite, "CLI: force-overwrite");
    success &= TestUtils::assertTrue(opts.enableLogging, "CLI: enable logging");
    success &= TestUtils::assertEqual(std::string("logs"), opts.logDir.filename().string(), "CLI: log-dir name");
    success &= TestUtils::assertEqual(LogLevel::Error, opts.logLevel, "CLI: log-level");
    return success;
}

bool ArgumentParseTest::testColorMode() {
    const char* argv[] = {
        "prunecopy",
        "--source", "src",
        "--destination", "dst",
        "--color", "always"
    };
    int argc = sizeof(argv) / sizeof(argv[0]);
    PruneOptions opts;

    ArgumentParser::parse(argc, const_cast<char**>(argv), opts);
    return TestUtils::assertEqual(ColorMode::Always, opts.colorMode, "ColorMode: always");
}

bool ArgumentParseTest::testDeprecatedDetection() {
    const char* argv[] = {
        "prunecopy",
        "../source",
        "../target",
        "--cmdln-out-off"  // deprecated
    };
    int argc = sizeof(argv) / sizeof(argv[0]);
    PruneOptions opts;

    ArgumentParser::clearDeprecatedFlagLog(); // reset buffer
    ArgumentParser::parse(argc, const_cast<char**>(argv), opts);

    std::ostringstream out;
    std::streambuf* oldCout = std::cout.rdbuf(out.rdbuf());
    ArgumentParser::emitDeprecatedWarnings();
    std::cout.rdbuf(oldCout);

    std::string result = out.str();
    bool success = true;
    success &= TestUtils::assertTrue(result.find("deprecated") != std::string::npos, "Deprecated: warning present");
    success &= TestUtils::assertTrue(result.find("--cmdln-out-off") != std::string::npos, "Deprecated: flag mentioned");
    return success;
}

bool ArgumentParseTest::testDeprecatedClear() {
    ArgumentParser::clearDeprecatedFlagLog();

    std::ostringstream out;
    std::streambuf* oldCout = std::cout.rdbuf(out.rdbuf());
    ArgumentParser::emitDeprecatedWarnings();
    std::cout.rdbuf(oldCout);

    return TestUtils::assertEqual(std::string(""), out.str(), "Deprecated: no output after clear");
}
