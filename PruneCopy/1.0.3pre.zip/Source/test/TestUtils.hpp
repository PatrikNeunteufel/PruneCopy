#pragma once

#include <iostream>
#include <string>
#include <sstream>
#include <type_traits>
#include <filesystem>

namespace TestUtils {

    // *** Basis-Version für "alles, was streambar ist" ***
    template<typename T>
    auto toString(const T& value) -> decltype(std::declval<std::ostream&>() << value, std::string()) {
        std::ostringstream oss;
        oss << value;
        return oss.str();
    }

    // *** Für std::string direkt ***
    inline std::string toString(const std::string& value) {
        return value;
    }

    // *** Für const char* ***
    inline std::string toString(const char* value) {
        return std::string(value);
    }

    // *** Für Enums ***
    template<typename T>
    typename std::enable_if<std::is_enum<T>::value, std::string>::type
        toString(const T& value) {
        return std::to_string(static_cast<int>(value));
    }

    // *** Für fs::path ***
    inline std::string toString(const std::filesystem::path& path) {
        return path.string();
    }

    // ************** assertEqual **************
    template<typename T, typename U>
    bool assertEqual(const T& expected, const U& actual, const std::string& message = "") {
        const std::string expectedStr = toString(expected);
        const std::string actualStr = toString(actual);

        if (expectedStr != actualStr) {
            std::cout << "[FAIL] " << message
                << ": expected '" << expectedStr
                << "', got '" << actualStr << "'" << std::endl;
            return false;
        }
        else {
            std::cout << "[PASS] " << message << std::endl;
            return true;
        }
    }

    // ************** assertTrue / assertFalse **************
    bool assertTrue(bool condition, const std::string& message = "");

    bool assertFalse(bool condition, const std::string& message = "");

} // namespace TestUtils
