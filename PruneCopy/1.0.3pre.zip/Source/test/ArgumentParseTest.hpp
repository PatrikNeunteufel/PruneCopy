/*****************************************************************//**
 * @file   ArgumentParseTest.hpp
 * @brief  Header for testing CLI argument parsing (ArgumentParser)
 *
 * @author Patrik Neunteufel
 * @date   April 2025
 *********************************************************************/

#pragma once

class ArgumentParseTest {
public:
    static bool run();

private:
    static bool testLegacyMode();
    static bool testFullCLIMode();
    static bool testColorMode();
    static bool testDeprecatedDetection();
    static bool testDeprecatedClear();
};
